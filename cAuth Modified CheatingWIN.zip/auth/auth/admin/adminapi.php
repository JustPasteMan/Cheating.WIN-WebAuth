<?php

include_once("../deps/config.php");
include_once("../funcs/general.php");

global $con;


if (!$_POST['request_type']) {
    return;
}

if ($_POST['request_type'] == 'generate_key') {
    if (!$_POST['key_amount'] || !$_POST['day_amount'] || !$_POST['program_name']) {
        return;
    } else {
        $licenses = '';
        $amount = $_POST['key_amount'];
        $days = $_POST['day_amount'];

        for($i = 0; $i < $amount; $i++){
            $license = general::gen_license();

            $con->query("INSERT INTO licenses (reseller, license, days, program) VALUES(?,?,?,?)", ['level', $license, $days, $_POST['program_name']]);

            $licenses .= $license;
        }

        echo $licenses;
    }
} else if ($_POST['request_type'] == 'reset_hwid') {
    if (!$_POST['license'] || !$_POST['program_name']) {
        return;
    } else {
        $license = $_POST['license'];

        $con->query("UPDATE licenses SET hwid='0' WHERE license=? AND program=?", [$license, $_POST['program_name']]);
    }
} else if ($_POST['request_type'] == 'ban_key') {
    if (!$_POST['license'] || !$_POST['program_name']) {
        return;
    } else {
        $license = $_POST['license'];

        $con->query("UPDATE licenses SET banned=1, ban_reason=? WHERE license=? AND program=?", ["DC-Command-Ban", $license, $_POST['program_name']]);
    }
} else if ($_POST['request_type'] == 'unban_key') {
    if (!$_POST['license'] || !$_POST['program_name']) {
        return;
    } else {
        $license = $_POST['license'];

        $con->query("UPDATE licenses SET banned=0, ban_reason=? WHERE license=? AND program=?", ["not_banned", $license, $_POST['program_name']]);
    }
} else if ($_POST['request_type'] == 'key_exist_check') {
    if (!$_POST['license']) {
        return;
    } else {
        $license = $_POST['license'];
        $r_query = $con->query("SELECT * FROM licenses WHERE `license`=?", [$license]);
        if ($r_query->numRows() > 0)
        {
            echo "Exist";
        }
        elseif ($r_query->numRows() == 0)
        {
            echo "Not_Exist";
        }
    }
}
