<?php
include("../funcs/panel.php");
include("globals.php");

if(panel\session_check() != panel\responses::success)
    echo "ERROR";

if(isset($_GET["gen_licenses"])){
        echo (panel\create_licenses($_GET["amount"], $_GET["days"], $_GET["reseller"]));
}

?>