<?php

include_once("../deps/config.php");
include_once("../funcs/general.php");

global $con;

if (!$_GET['request_type']) {
    return;
}

if ($_GET['request_type'] == 'generate_key') {
    if (!$_GET['key_amount'] | !$_GET['day_amount'] | !$_GET['program_name']) {
        return;
    } else {
        $licenses = '';
        $amount = $_GET['key_amount'];
        $days = $_GET['day_amount'];

        for($i = 0; $i < $amount; $i++){
            $license = general::gen_license();

            $con->query("INSERT INTO licenses (reseller, license, days, program) VALUES(?,?,?,?)", ['level', $license, $days, $_GET['program_name']]);

            $licenses .= $license . ' | ';
        }

        echo $licenses;
    }
} else if ($_GET['request_type'] == 'reset_hwid') {
    if (!$_GET['license']  !$_GET['program_name']) {
        return;
    } else {
        $license = $_GET['license'];

        $con->query("UPDATE licenses SET hwid='0' WHERE license=? AND program=?", [$license, $_GET['program_name']]);
    }
} else if ($_GET['request_type'] == 'delete_key') {
    if (!$_GET['license']  !$_GET['program_name']) {
        return;
    } else {
        $license = $_GET['license'];

        $con->query("DELETE FROM licenses WHERE license=? AND program=?", [$license, $_GET['program_name']]);

    }
}
