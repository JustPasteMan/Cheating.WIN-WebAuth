<?php
$is_owner = panel\get_group() == "owner";
$is_admin = panel\get_group() == "admin";
$is_reseller = panel\get_group() == "reseller";
$is_level = $_SESSION["reseller"] == "level";