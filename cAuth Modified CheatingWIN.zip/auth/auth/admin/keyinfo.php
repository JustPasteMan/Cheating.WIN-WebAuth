<?php

include_once("../deps/config.php");
include_once("../funcs/general.php");

if (!$_POST['license'] || !$_POST['value']) {
    return;
}

$license = $_POST['license'];
$value = $_POST['value'];

function return_key_info($license, $value){
  global $con;
  $r_query = $con->query("SELECT * FROM licenses WHERE `license`=?", [$license]);
  if ($r_query->numRows() > 0)
  {
      $array = $r_query->fetch();
      return $array[$value];
  }
}


echo return_key_info($license , $value)


?>
