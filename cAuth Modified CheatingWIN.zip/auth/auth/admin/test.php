<?php
namespace api;
use general;

include_once("../deps/config.php");
include_once("../funcs/general.php");

class responses{
    const invalid_license = "invalid_license";
    const invalid_hwid = "invalid_hwid";
    const expired_sub = "expired_sub";
    const banned_license = "banned_license";
    const success = "success";

    const logged_in = "logged_in";
}

#region hwid
function update_hwid($license, $hwid){
    global $con;

    $con->query("UPDATE licenses SET hwid=? WHERE license=? AND program=?", [$hwid, $license, $_SESSION["program_name"]]);

    return responses::success;
}

function check_hwid($license_data, $hwid){
    global $con;

    if($license_data["hwid"] == '0')
        return update_hwid($license_data["license"], $hwid);

    if($license_data["hwid"] != $hwid)
        return responses::invalid_hwid;

    return responses::success;
}
#endregion
function fetch_license($license){
    global $con;

    $l_query = $con->query("SELECT * FROM licenses WHERE license=? AND program=?", [$license, $_SESSION["program_name"]]);

    if($l_query->numRows() > 0)
        return $l_query->fetch();

    return responses::invalid_license;
}

function update_license_ip($license_data){
    global $con;

    $con->query("UPDATE licenses SET ip=? WHERE license=? AND reseller=? AND program=?", [general::get_ip(), $license_data["license"], $license_data["reseller"], $_SESSION["program_name"]]);

    return responses::success;
}

function update_activated_at($license_data){
    global $con;

    if($license_data["activated_at"] == "not_activated")
        $con->query("UPDATE licenses SET activated_at=? WHERE license=? AND reseller=? AND program=?", [time(), $license_data["license"], $license_data["reseller"], $_SESSION["program_name"]]);

    return responses::success;
}

#region sub
function update_sub($license_data){
    global $con;

    if($license_data["days"] == '0.0.0.5') //0.0.0.5 means 3 hour keys kekw
        $final_timestamp = strtotime("+3 hours");
    else
        $final_timestamp = strtotime("+" . $license_data["days"] . " days");

    $con->query("UPDATE licenses SET expiry=? WHERE license=? AND program=?", [$final_timestamp, $license_data["license"], $_SESSION["program_name"]]);

    return responses::success;
}

function check_sub($license_data){
    if($license_data["expiry"] == 0)
        return update_sub($license_data);

    if($license_data["expiry"] > time())
        return responses::success;

    return responses::expired_sub;
}
#endregion

function login($license, $hwid) {
    $license_data = fetch_license($license);

    if($license_data == responses::invalid_license)
        return $license_data;

    if($license_data["banned"] == 1)
        return responses::banned_license;

    $uc_sub = check_sub($license_data);

    if($uc_sub != responses::success)
        return $uc_sub;

    $uc_hwid = check_hwid($license_data, $hwid);

    if($uc_hwid != responses::success)
        return $uc_hwid;

    update_activated_at($license_data);
    update_license_ip($license_data);

    return responses::logged_in . '|' . $license_data["expiry"];
}