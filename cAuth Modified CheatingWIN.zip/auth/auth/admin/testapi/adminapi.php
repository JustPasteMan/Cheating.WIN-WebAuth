<?php

include_once("../deps/config.php");
include_once("../funcs/general.php");

global $con;

if (!$_POST['request_type']) {
    return;
}

if ($_POST['request_type'] == 'generate_key') {
    if (!$_POST['key_amount'] || !$_POST['day_amount'] || !$_POST['program_name']) {
        return;
    } else {
        $licenses = '';
        $amount = $_POST['key_amount'];
        $days = $_POST['day_amount'];

        for($i = 0; $i < $amount; $i++){
            $license = general::gen_license();

            $con->query("INSERT INTO licenses (reseller, license, days, program) VALUES(?,?,?,?)", ['level', $license, $days, $_POST['program_name']]);

            $licenses .= $license . ' | ';
        }

        echo $licenses;
    }
} else if ($_POST['request_type'] == 'reset_hwid') {
    if (!$_POST['license'] || !$_POST['program_name']) {
        return;
    } else {
        $license = $_POST['license'];

        $con->query("UPDATE licenses SET hwid='0' WHERE license=? AND program=?", [$license, $_POST['program_name']]);
    }
} else if ($_POST['request_type'] == 'delete_key') {
    if (!$_POST['license'] || !$_POST['program_name']) {
        return;
    } else {
        $license = $_POST['license'];

        $con->query("DELETE FROM licenses WHERE license=? AND program=?", [$license, $_POST['program_name']]);

    }
}