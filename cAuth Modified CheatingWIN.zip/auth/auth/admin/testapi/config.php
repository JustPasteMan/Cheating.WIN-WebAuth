<?php
if(!isset($_SESSION))
    session_start();

include_once('simpsql.php');

$enc_key = "!D@bx?@y{X8^q~t+_b_r5}j=|92`!g6g";

try{
    $con = new SimpleMySQLi("localhost", "easyuofd_main_user", "F$2yB}YsU1z.", "easyuofd_auth_db");
    //defining the db object
}
catch(SimpleMySQLiException $ex){
    die($ex->getMessage());
}