<?php
class general{
    static function get_ip(){
        if(isset($_SERVER["REMOTE_ADDR"]))
            return $_SERVER["REMOTE_ADDR"];

        return $_SERVER["HTTP_X_FORWARDED_FOR"];
    }

    //https://stackoverflow.com/questions/4356289/php-random-string-generator
    static function random_str(
        int $length = 64,
        string $keyspace = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ): string {
        if ($length < 1) {
            throw new \RangeException("Length must be a positive integer");
        }
        $pieces = [];
        $max = mb_strlen($keyspace, '8bit') - 1;
        for ($i = 0; $i < $length; ++$i) {
            $pieces []= $keyspace[random_int(0, $max)];
        }
        return implode('', $pieces);
    }

    static function gen_license(){
        $out = '';

        for($i = 0; $i < 4; $i++)
            $out .= self::random_str(5) . '-';

        return substr($out, 0, -1);
        //expected output : XHUAS-POWLK-AJNMD-APKLD
    }

    static function xss_clean($string){
        return htmlentities($string);
    }
}