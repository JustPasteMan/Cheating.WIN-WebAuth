<?php
namespace panel;
use general;

include_once("config.php");
include_once("general.php");

class responses{
    const reseller_already_exists = "reseller_already_exists";
    const invalid_reseller = "credentials are nonexistent";
    const wrong_password = "the reseller's password is wrong";
    const success = "success";

    const invalid_session = "invalid_session";
}

#region reseller
function update_reseller_ip($name){
    global $con;

    $con->query("UPDATE resellers SET ip=? WHERE `name`=?", [general::get_ip(), $name]);

    return responses::success;
}

function fetch_reseller($name) {
    global $con;

    $r_query = $con->query("SELECT * FROM resellers WHERE `name`=?", [$name]);

    if ($r_query->numRows() > 0)
        return $r_query->fetch();

    return responses::invalid_reseller;
}

function delete_reseller($name){
    global $con;

    if($name == $_SESSION["reseller"])
        die("are you retarded????? trying to delete yourself, imagine kek");

    if($name == "level")
        die("dont be tryna delete the all mighty one: level");

    $con->query("DELETE FROM resellers WHERE `name`=?", [$name]);

    return responses::success;
}

function fetch_all_resellers(){
    global $con;

    $qr = $con->query("SELECT * FROM resellers");

    return $qr->fetchAll();
}

function create_reseller($name, $pass, $role){
    global $con;

    if(is_array(fetch_reseller($name)))
        return responses::reseller_already_exists;

    $hash = password_hash($pass, PASSWORD_BCRYPT);

    $role = filter_var($role, FILTER_SANITIZE_NUMBER_INT);

    $con->query("INSERT INTO resellers (`name`, pass, adm) VALUES (?,?,?)", [$name, $hash, $role]);

    return responses::success;
}
#endregion

function login($name, $pass, $program) {
    $_SESSION["program_name"] = $program;

    $reseller_data = fetch_reseller($name);

    if($reseller_data == responses::invalid_reseller)
        return $reseller_data;

    if(!password_verify($pass, $reseller_data["pass"]))
        return responses::wrong_password;

    update_reseller_ip($name);

    $_SESSION["access"] = md5(general::get_ip()); //anti session hijacking
    $_SESSION["reseller"] = general::xss_clean($reseller_data["name"]);
    $_SESSION["group"] = $reseller_data["adm"];

    return responses::success;
}

#region general
function alert($message){
    ?><script src="../assets/js/jquery-3.5.1.min.js"></script>
    <script src="../assets/js/sweet-alert/sweetalert.min.js"></script>
    <script>$(document).ready(function() { swal('Alert', '<?php echo $message; ?>', 'info'); }) </script><?php
}

function display_notifications(){
    ?><li class="onhover-dropdown"><div class="notification-box"><i data-feather="bell"></i><span class="badge badge-pill badge-secondary">1</span></div><ul class="notification-dropdown onhover-show-div">
                <li>
                    <p class="f-w-600 font-roboto">You have 1 notifications</p>
                </li>
                <li>
                    <p class="mb-0"><i class="fa fa-circle-o mr-3 font-primary"> </i>Release<span class="pull-right">1.0</span></p>
                </li></ul></li><?php
}

function session_check(){
    if(!isset($_SESSION["access"]) || $_SESSION["access"] != md5(general::get_ip()))
        return responses::invalid_session;

    return responses::success;
}

function get_group($curr_group = null){
    if($curr_group == null)
        $curr_group = $_SESSION["group"];

    switch($curr_group){
        case 0:
            return "reseller";
        case 1:
            return "admin";
        case 2:
            return "owner";
        default:
            return "unknown";
    }
}
#endregion

#region managing
function fetch_all_licenses($value, $reseller_only = true){
    global $con;

    $all_q = ($reseller_only) ? $con->query("SELECT * FROM licenses WHERE reseller=? AND program=?", [$_SESSION["reseller"], $_SESSION["program_name"]]) :
        $con->query("SELECT * FROM licenses WHERE program=?", $value);

    return $all_q->fetchAll();
}

function create_licenses($amount, $days, $reseller){
    global $con;

    $licenses = '';

    for($i = 0; $i < $amount; $i++){
        $license = general::gen_license();
        $con->query("INSERT INTO licenses (reseller, license, days, program) VALUES(?,?,?,?)", [$reseller, $license, $days, $_SESSION["program_name"]]);

        $licenses .= $license . '|';
    }

    return $licenses;
}

function reset_license_hwid($license, $reseller){
    global $con;

    $con->query("UPDATE licenses SET hwid='0' WHERE license=? AND reseller=? AND program=?", [$license, $reseller, $_SESSION["program_name"]]);

    return responses::success;
}

function ban_license($license, $reseller, $reason = 'none', $unban = false)
{
    global $con;

    (!$unban) ?
        $con->query("UPDATE licenses SET banned='1', ban_reason=? WHERE reseller=? AND license=? AND program=?", [$reason, $reseller, $license, $_SESSION["program_name"]])
    :
        $con->query("UPDATE licenses SET banned='0' WHERE reseller=? AND license=? AND program=?", [$reseller, $license, $_SESSION["program_name"]]);

    return responses::success;
}

function delete_license($license, $reseller){
    global $con;

    $con->query("DELETE FROM licenses WHERE license=? AND reseller=? AND program=?", [$license, $reseller, $_SESSION["program_name"]]);

    return responses::success;
}
#endregion
