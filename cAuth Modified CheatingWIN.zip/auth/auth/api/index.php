<?php
include_once("../funcs/api.php");
include_once("../deps/aesenc.php");

if($_SERVER["HTTP_USER_AGENT"] != "cheating.win")
    die("wrong user agent");

$iv = AesEncryption::decrypt_string($_POST["csv"], $enc_key, "^#j?)<z?*J.SsmUT");

$_SESSION["program_name"] = AesEncryption::decrypt_string($_POST["prd"], $enc_key, $iv);

$license = AesEncryption::decrypt_string($_POST["lcs"], $enc_key, $iv);

$hwid = AesEncryption::decrypt_string($_POST["hwd"], $enc_key, $iv);

$result = api\login($license, $hwid);

die(AesEncryption::encrypt_string($result, $enc_key, $iv));