<?php

class AesEncryption {
    private const method = "aes-256-cbc";

    public static function encrypt_string($plain_text, $key, $iv){
        $enc_bytes = openssl_encrypt($plain_text, self::method, $key, true, $iv);

        $encoded_output = base64_encode($enc_bytes);

        return $encoded_output;
    }

    public static function decrypt_string($cipher_text, $key, $iv){
        $decoded_bytes = base64_decode($cipher_text);

        $dec_plain = openssl_decrypt($decoded_bytes, self::method, $key, true, $iv);

        return $dec_plain;
    }
}