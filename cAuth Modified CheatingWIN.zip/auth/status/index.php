
<?php

function returnDate(){
$today= date("m.d.y");
  return $today;
}

function setButton($status){

  if($status == "ud")
  {


  }

}

?>




<!DOCTYPE html>
<html class="no-js" lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>STATUS Cheating.Win</title>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- favicon -->
      <script src="js/head-WnASDwCRkl3C4510tLwBl2lq9wo.js"></script><link rel="shortcut icon" type="image/png" href="">
      <!-- all css here -->
      <!-- bootstrap v3.3.6 css -->
      <link rel="stylesheet" href="css/css-bootstrap.min.css">
      <link rel="stylesheet" href="css/css-font-awesome.min.css">
      <link rel="stylesheet" href="css/css-owl.carousel.min.css">
      <link rel="stylesheet" href="css/css-owl.theme.default.min.css">
      <link rel="stylesheet" href="css/css-animate.min.css">
      <link rel="stylesheet" href="css/css-lightcase.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/css-responsive.css">
   </head>
   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- header-area start -->
      <div id="sticker" class="header-area default-header">
         <div class="container">
            <div class="row">
               <!-- LOGO FOR ONLY MOBILE -->
               <div class="col-md-2 col-sm-2 visible-xs">
                  <div class="logo">
                     <!-- Brand -->
                     <a class="navbar-brand page-scroll sticky-logo" href="index.html">
                     <img src="images/img-logo.png" alt="">
                     </a>
                  </div>
               </div>
               <!-- LOGO FOR ONLY MOBILE -->
               <!-- MENU FOR TAB, PC, LAP ONLY -->
               <div class="col-md-5 col-sm-5 hidden-xs">

                  <!-- END: Navigation -->
               </div>
               <!-- LOGO FOR ONLY TAB,PC ,LAP -->
               <div class="col-md-2 col-sm-2 hidden-xs">
                  <div class="logo">
                     <!-- Brand -->
                     <a class="navbar-brand page-scroll sticky-logo" href="index.html">
                     <img class="cntr" src="images/img-logo.png" alt="">
                     </a>
                  </div>
               </div>
               <!-- LOGO FOR ONLY TAB,PC ,LAP -->
               <div class="col-md-5 col-sm-5 hidden-xs">

                  <!-- END: Navigation -->
               </div>
               <!-- MENU FOR TAB, PC, LAP ONLY END -->
               <!-- MENU FOR MOBILE ONLY  START-->
               <div class="col-md-5 col-sm-5 visible-xs">
                  <!-- Navigation -->

                  <!-- END: Navigation -->
               </div>
               <!-- MENU FOR MOBILE ONLY START -->
            </div>
         </div>
      </div>
      <!-- header bottom End -->
      <!-- header end -->
      <!-- banner -->
      <div class="live-status" style="background-image: url('img/ls/bg.png'); ">
         <!-- ----- -->




         <!-- banner -->
         <section class="banner-inner">
            <div class="container">
               <div class="inner-title text-center">
                  <h1><span>STATUS</span> PAGE</h1>
               </div>
            </div>




         </section>
         <section class="live-item-sec">
            <div class="container">
               <!-- item -->
               <div class="live-items">
                  <div class="live-title"><img src="images/ls-ic-hwid.png"> HWID Spoofer</div>
                  <!-- box-item -->
                  <div class="live-box">
                     <h1>HWID Spoofer</h1>
                     <h2>Updated on<span> <?php echo returnDate(); ?> </span></h2>
                     <span class="live-btn live-green">UNDETECTED</span>
                  </div>
               </div>


               <div class="live-items">
                  <div class="live-title"><img src="images/Fortnite-logo.png"> Fortnite Public External V2</div>
                  <!-- box-item -->
                  <div class="live-box">
                     <h1> Public External V2</h1>
                     <h2>Updated on<span> <?php echo returnDate(); ?></span></h2>
                     <span class="live-btn live-green">UNDETECTED</span>
                  </div>
                  <!-- box-item -->
               </div>





               <!-- item -->
               <!-- item -->
               <div class="live-items">
                  <div class="live-title"><img src="images/Fortnite-logo.png"> Fortnite Legit Internal</div>
                  <!-- box-item -->
                  <div class="live-box">
                     <h1>Legit Internal</h1>
                     <h2>Updated on<span> <?php echo returnDate(); ?></span></h2>
                     <span class="live-btn live-orange">TESTING</span>
                  </div>
               </div>
               <!-- item -->
               <!-- item -->
               <div class="live-items">
                  <div class="live-title"><img src="images/Fortnite-logo.png"> Fortnite Legit External</div>
                  <!-- box-item -->
                  <div class="live-box">
                     <h1> Legit External</h1>
                     <h2>Updated on<span> <?php echo returnDate(); ?></span></h2>
                 <span class="live-btn live-orange">TESTING</span>
                  </div>
               </div>
               <!-- item -->
               <!-- item -->
               <div class="live-items">
                  <div class="live-title"><img src="images/Fortnite-logo.png"> Fortnite Rage Internal</div>
                  <!-- box-item -->
                  <div class="live-box">
                     <h1> Rage Internal</h1>
                     <h2>Updated on <span><?php echo returnDate(); ?></span></h2>
                 <span class="live-btn live-orange">TESTING</span>
                  </div>
               </div>


            </div>
         </section>
         <!-- ----- -->
      </div>
    <!-- footer -->


      <section class="copyright">
         <div class="container">
            <div class="row">
               <div class="col-md-7">
                  <p>Copyright &copy; 2021 Cheating.Win - All rights reserved</p>
               </div>
               <div class="col-md-5">
                  <div class="menu-item">

                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- JS     -->
      <script src="js/2411-js-jquery.js"></script>
      <script src="js/7198-js-bootstrap.js"></script>
      <script src="js/8253-js-wow.min.js"></script>
      <script src="js/9559-js-owl.carousel.min.js"></script>
      <script src="js/6813-js-lightcase.js"></script>
      <script src="js/1638-js-main.js"></script>
   </body>
</html>
