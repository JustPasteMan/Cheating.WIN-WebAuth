(function ($) {
    "use strict";

    /*---------------------
     TOP Menu Stick
    --------------------- */
    var s = $("#sticker");
    var pos = s.position();
    $(window).on('scroll', function () {
        var windowpos = $(window).scrollTop();
        if (windowpos > pos.top) {
            s.addClass("stick");
        } else {
            s.removeClass("stick");
        }
    });
    /*----------------------------
 Navbar nav
------------------------------ */

    var menu_btn = $('.menu-btn1');
    menu_btn.on("click", function () {
        $(this).toggleClass("active");
        $(".icon-header").toggleClass("active");
        $(".default-header").toggleClass("active");
    });



 
 // hide collpas branches
    var $tabgroup = $('#tab-items');
    $tabgroup.on('show.bs.collapse', '.collapse', function () {
        $tabgroup.find('.collapse.in').collapse('hide');
    });


 $("#color1").click(function(){
    $(".cheat-futur .fut-box .tab-box ul").css("background", "#d4213a");
  });

 $("#color2").click(function(){
    $(".cheat-futur .fut-box .tab-box ul").css("background", "#b41c31");
  });

    $('body').addClass('loaded');
    setTimeout(function () {
        $('#loader-wrapper').fadeOut();
    }, 3000);



 $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      // event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        // window.location.hash = hash;
      });
    } // End if
  });
  
    $('a[data-rel^=lightcase]').lightcase();




    //Initiat WOW JS
    new WOW().init();

})(jQuery);